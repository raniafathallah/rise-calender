import {createContext} from 'react';
 
const IdContext=createContext(null);
export default IdContext;