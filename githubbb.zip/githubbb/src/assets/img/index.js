const images = {
    svg: {
        calendar: require('./').default,
    }
};

export default images;